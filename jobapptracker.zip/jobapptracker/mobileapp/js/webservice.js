
function webservice (serviceAddress, postPacket) {
	
	//this function contacts the webservice and returns
	//the result string.
	//ServiceAddress is the address of the service.
	//PostPacket is a JSON object that is to be provided
	//as a post to the service.
	
	return "beaubeau";
	
}

