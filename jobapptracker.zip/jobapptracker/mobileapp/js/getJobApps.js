
function getJobApps (username, passwordhash) {
	
	//Sends an AJAX request to the server and retrieves
	//a JSONarray of all the job applications for the user.
	//Username is the user's username and passwordhash is
	//the salted hashed password.
	//The function returns a javascript array of JobApp objects.
	
	var result = new Array();
	
	//create an XMLHttpRequest
	var xhttp = new XMLHttpRequest();	
	
	//define the action to be done when the XMLHttpRequest is finished
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			//convert the JSONarray to a javascript array
			jobAppsListJSON = JSON.parse(this.responseText);
			
			//convert each JSON object in the javascript array
			//to a JobApp object
			for (JSONjobApp in jobAppsListJSON) {
				jobApp = JSON.parse(JSONjobApp);
				result.push(jobApp);
			};
			return result;
		};
	};
	postString = "username=" + username + "&passwordhash=" + passwordhash;
	xhttp.open("POST", "applicationsJSON.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send(postString);
	
}