/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
 
 
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
		
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
	
};

var app2 = {
	initialize: function() {
		this.bindEvents();
	},
	
	bindEvents: function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},
	
	onDeviceReady: function() {
		alert('device is reeeeeedy');
		var btn = document.getElementById('take_photo');
		btn.addEventListener('click', app2.takephoto, false);
	},
	takephoto: function() {
		function onSuccess(uri) {
			var img = document.getElementById('camera_image');
			img.src = uri;
		};
		function onFailure(msg) {
			alert("error happened" + msg);
		};
		alert("button was pushed");
		navigator.camera.getPicture(onSuccess, onFailure);
	}
};


var app3 = {
	initialize: function() {
		this.bindEvents();
	},
	
	bindEvents: function() {
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},
	
	onDeviceReady: function() {
		var btn = document.getElementById('sendSearch');
		btn.addEventListener('click', this.searchCompanies, false);
		var dbres = [
		app3.createList(dbres, "listHere");
	},
	
	createList: function (dbResults, listId) {
	
	//this function creates an html list from the input
	//and inserts the list into element with id = listId.
	//The input dbResults is an array of JobApp objects.
	//The input listId is a string (the id of the html 
	//element in to which the list is required).
	
	alert('the createlist function was called');
	
	var list = document.createElement('ul');
	
	for (jobApp in dbResults) {
		
		//get details of jobApp
		appCompany = jobApp.Company();
		appTitle = jobApp.Title();
		appCloses = jobApp.Closes();
		
		//create div element for each detail of jobApp
		var divCompany = document.createElement('div');
		var divTitle = document.createElement('div');
		var divCloses = document.createElement('div');
		
		//add text to each div element
		divCompany.appendChild(document.createTextNode(appCompany));
		divTitle.appendChild(document.createTextNode(appTitle));
		divCloses.appendChild(document.createTextNode(appCloses));
		
		//create list item
		var listItem = document.createElement('li');
		
		//add div elements to listItem
		listItem.appendChild(divCompany);
		listItem.appendChild(divTitle);
		listItem.appendChild(divCloses);
		list.appendChild(item);
	}
	
	document.getElementById(listId).appendChild(list);
	
},
	
	searchCompanies: function() {
		alert("the search method was called");
	},
	
	searchCompanies2: function() {
		alert("the search method was called");
		var str = "whatwaht";
		if (window.XMLHttpRequest) {
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function() {
			if (this.readyState==4 && this.status==200) {
				alert("the response text is " + this.responseText);
				document.getElementById("toChange").innerHTML=this.responseText;
			}
		}
		xmlhttp.open("GET","http://127.0.0.1/searchCompanies.php?q="+str,true);
		xmlhttp.send();
	}
};




	
