
function createList (dbResults, listId) {
	
	//this function creates an html list from the input
	//and inserts the list into element with id = listId.
	//The input dbResults is an array of JobApp objects.
	//The input listId is a string (the id of the html 
	//element in to which the list is required).
	
	alert('the createlist function was called');
	
	var list = document.createElement('ul');
	
	for (jobApp in dbResults) {
		
		//get details of jobApp
		appCompany = jobApp.Company();
		appTitle = jobApp.Title();
		appCloses = jobApp.Closes();
		
		//create div element for each detail of jobApp
		var divCompany = document.createElement('div');
		var divTitle = document.createElement('div');
		var divCloses = document.createElement('div');
		
		//add text to each div element
		divCompany.appendChild(document.createTextNode(appCompany));
		divTitle.appendChild(document.createTextNode(appTitle));
		divCloses.appendChild(document.createTextNode(appCloses));
		
		//create list item
		var listItem = document.createElement('li');
		
		//add div elements to listItem
		listItem.appendChild(divCompany);
		listItem.appendChild(divTitle);
		listItem.appendChild(divCloses);
		list.appendChild(item);
	}
	
	document.getElementById(listId).appendChild(list);
	
}

