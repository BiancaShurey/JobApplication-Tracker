<?php require 'phpfunctions/header.php';?>

<body>
<div class="cover-bg">
  <div class="row">
    <div class="col-sm-12 center-block text-center">
    <h1>Contact</h1>
  </div>
  </div>
  <br><br>

  <div class="row">
    <div class="container">

    <form class="form-horizontal" role="form" name="registration" method="post" action="phpfunctions/database1.php">
        <!-- Organisation Name-->
        <div class="form-group">
            <label for="uqID" class=" col-sm-4   control-label">Name</label>
            <div class="col-xs-8 col-md-5  ">
                <input type="text" id="uqID" name="name" placeholder="Name" class="form-control" required="Required">
            </div>
        </div>

        <!-- Company-->
        <div class="form-group">
            <label for="fullName" class=" col-xs-4 control-label">Company</label>
            <div class="col-xs-8 col-md-5">
                <input type="text" name="diversity" id="company" placeholder="Company" class="form-control" required="Required">
            </div>
        </div>

        <!-- Type -->
        <div class="form-group">
            <label for="major" class=" col-xs-4 control-label">Type</label>
            <div class="col-xs-8 col-md-5">
                <input type="text" name="type" id="major" placeholder="Type" class="form-control" required="Required">
            </div>
        </div>


        <!-- Location -->
        <div class="form-group">
            <label for="email" class=" col-xs-4 control-label">Location</label>
            <div class="col-xs-8 col-md-5">
                <input type="text" name="location" id="email" placeholder="Search" class="form-control" required="Required">
            </div>
        </div>

		<!-- Phone -->
        <div class="form-group">
            <label for="email" class=" col-xs-4 control-label">Phone</label>
            <div class="col-xs-8 col-md-5">
                <input type="text" name="phone" id="email" placeholder="Phone" class="form-control" required="Required">
            </div>
        </div>

		<!-- Email -->
        <div class="form-group">
            <label for="email" class=" col-xs-4 control-label">Email</label>
            <div class="col-xs-8 col-md-5">
                <input type="email" name="growth" id="email" placeholder="Email" class="form-control" required="Required">
            </div>
        </div>

		<!-- Location -->
        <div class="form-group">
            <label for="email" class=" col-xs-4 control-label">Location</label>
            <div class="col-xs-8 col-md-5">
                <input type="text" name="location" id="email" placeholder="Location" class="form-control" required="Required">
            </div>
        </div>

        <!-- Submit Registration-->
        <div class="form-group">
          <div class="col-xs-4 "></div>
            <div class="col-xs-8 col-md-5 center-block">
                <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form> <!-- /form -->
  </div>
  </div>
</div>

</body></html>
