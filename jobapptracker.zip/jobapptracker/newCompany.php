
<?php
require_once 'phpfunctions/classes.php';
require_once 'phpfunctions/header.php';
require_once 'phpfunctions/config.php';
$current = new currentUser();	//the user that is currently logged in (if any)
if (!$current->username())
{
	//no user is logged in, so redirect to login page
	$_SESSION['message'] = "Please sign in to use your account";
	header("Location: login.php");
	exit;
}

$username = $current->username();
?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Job Application Tracker</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/stylesheet.css" rel="stylesheet">
</head>
<body>
	
<div class="main">
	<div class="container">
		<div class="Jumbotron">
          <h1>Add company</h1>
          <h2>add a new company to your list</h2>
        </div>
		
		<form class="form-horizontal" method="POST" id="companyForm">

			<div class="form-group">
				<label class="control-label col-sm-2" for="company">company:</label> 
				<div class="col-sm-10">  
					<input type="text" id="company" name="company" class="content" onkeyup="searchCompanies(this.value)" onblur="closeSuggestions()"/><br>
				</div>
			</div>
			<div>
				<ul class="list-group" id="livesearch">
					<!--Displays suggestions according to the user typing -->
				</ul>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="type">type:</label>
				<div class="col-sm-10">  
					<input type="text" id="type" name="type" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="industry">industry:</label>
				<div class="col-sm-10">  
					<input type="text" id="industry" name="industry" class="content"/><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="values">values:</label>
				<div class="col-sm-10">  
					<input id="values" type="text" name="values" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="diversity">diversity:</label>
				<div class="col-sm-10">  
					<input id="diversity" type="text" name="diversity" class="content" /><br>
				</div>
			</div>
			
			<div class="form-group">
				<label class="control-label col-sm-2" for="size">size:</label>
				<div class="col-sm-10">  
					<input id="size" type="text" name="size" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="finances">finances:</label>
				<div class="col-sm-10">  
					<input id="finances" type="text" name="finances" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="people">people:</label>
				<div class="col-sm-10">  
					<input id="people" type="text" name="people" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="website">website:</label>
				<div class="col-sm-10">  
					<input id="website" type="text" name="website" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="focus">focus:</label>
				<div class="col-sm-10">  
					<input id="focus" type="text" name="focus" class="content" /><br>
				</div>
			</div>
			
			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">  
					<button type="button" onclick="createCompany()" class="btn btn-default">Submit</button>
				</div>
			</div>
		</form>
	</div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

<script>

//Things to do when page is ready
$(document).ready(function(){
    //bind the livesearch results element so that it disappears after it is clicked
    $("#livesearch").click(function(){
        $("#livesearch").hide();
    });
});

var username = window.localStorage.getItem("username");
var password = window.localStorage.getItem("password");

function createCompany() {

	var company = document.getElementById("company").value;
	var type = document.getElementById("type").value;
	var industry = document.getElementById("industry").value;
	var values = document.getElementById("values").value;
	var diversity = document.getElementById("diversity").value;
	var size = document.getElementById("size").value;
	var finances = document.getElementById("finances").value;
	var people = document.getElementById("people").value;
	var website = document.getElementById("website").value;
	var focus = document.getElementById("focus").value;
	
	//Check that size is an integer (required for database)
	if (size.length == 0) {
		size = 0;
	} 
	size = parseInt(size);
	if (isNaN(size)) {
		alert('Hang on, company size must be an integer');
		return;
	}
	
	var postString = 
		"username=" + username + "&" + 
		"password=" + password + "&" + 
		"company=" + company + "&" + 
		"type=" + type + "&" + 
		"industry=" + industry + "&" + 
		"values=" + values + "&" + 
		"diversity=" + diversity + "&" + 
		"size=" + size + "&" + 
		"finances=" + finances + "&" + 
		"people=" + people + "&" + 
		"website=" + website + "&" + 
		"focus=" + focus;

	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function() {
		if (this.readyState==4 && this.status==200) {
			var trimmedResponse = this.responseText.replace(/^\s*/,'').replace(/\s*$/,'').toLowerCase();
			if (trimmedResponse == "ok") {
				alert("Bro, new company created");
				window.location.href = "userCompanies.html";
			} else {
				alert("oh no, the company couldn't be created, " + this.responseText);
			}
		}
	};
	xmlhttp.open("POST","https://infs3202-dwrqj.uqcloud.net/jobapptracker/mobileserver/createCompany.php" ,true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send(postString);
}

function closeSuggestions() {
	//closes the livesearch results box when the user clicks out of the Company field
	//hide the livesearch element (after a delay, to give time for the user to select an item
	//from the livesearch box)
	setTimeout(function(){$("#livesearch").slideUp();}, 500);
};
</script>

<script>

//this function enables a live search for the Company text field
function searchCompanies(str) {
	
	if (str.length==0) {
		$("#livesearch").empty();
		$("#livesearch").hide();
		//document.getElementById("livesearch").innerHTML="";
		//document.getElementById("livesearch").style.border="0px";
		return;
	}
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function() {
		if (this.readyState==4 && this.status==200) {
		
			//Convert response text to list and pass to
			//"displaySearch" method
			var list = JSON.parse(this.responseText);
			displaySearch(list);
		
		}
	};
	xmlhttp.open("GET","https://infs3202-dwrqj.uqcloud.net/jobapptracker/mobileserver/searchCompanies.php?q="+str,true);
	xmlhttp.send();
}
	
//Display the livesearch box with a list
function displaySearch(list) {

	$("#livesearch").empty();
	$("#livesearch").show();
	
	for (i=0; i<list.length; i++) {
	
		var result = list[i];
		var listItem = "<li class='list-group-item' onclick='selectResult(this)'>" + 
			result + "</li>";
		$("#livesearch").append(listItem);
	
	}
	
	//document.getElementById("livesearch").style.border="1px solid #A5ACB2";			

}

//Sets the Company field to the text contained in the clickedElement
function selectResult(clickedElement) {

	//alert('text is ' + clickedElement.innerText);
	$("#company").val(clickedElement.innerText);

}

</script>

</body>
</html>