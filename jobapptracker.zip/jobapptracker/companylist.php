	<?php

			require_once 'phpfunctions/header.php';

			// Create connection
			$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
			// Check connection
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}
			$currentUsername = $current->username();
			$sql = "SELECT * FROM companies WHERE username= '$currentUsername'";
			$result = mysqli_query($conn, $sql); ?>



<div class="container">
  <h2>Basic Table</h2>
        <a href="Company.php" class="btn btn-info" role="button" id='add'>Add new Company</a>
  <p></p>
  <table class="table">
    <thead>
      <tr>
        <th>Company</th>
        <th>Type</th>
        <th>Industry</th>
		<th>Value</th>
		<th>Diversity</th>
		<th>Size</th>
		<th>Finances</th>
		<th>People</th>
		<th>Website</th>
		<th>Focus</th>
      </tr>
    </thead>




	<tbody>
<?php
		while( $company = mysqli_fetch_array($result)){

		echo "<tr id='".$company['Company']."' href='contactDetails.php'><td>".$company['Company']."</td><td>".$company['Type']."</td><td>".$company['Industry']."</td><td>".$company['Values']."</td><td>".$company['Diversity']."</td><td>".$company['Size']."</td><td>".$company['Finances']."</td><td>".$company['People']."</td><td>".$company['Website']."</td><td>".$company['Focus']."</td></tr>";

	};
	mysqli_close($conn); ?>
	</tbody>
  </table>

</div>

<script>
jQuery(document).ready(function($) {
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});

$('tr[href]').on("click", function() {
	var companyClicked = $(this).attr('id');
	window.localStorage.setItem("company", companyClicked);
	window.location.href = 'companyDetails.php?company=' + companyClicked;
});
</script>

</body>
</html>
