<?php require 'phpfunctions/header.php';?>
<html
  <body>
    <div class="main">
      <div class="container">
        <div class="Jumbotron">
          <img src="images/logo.png" alt="Japlender - job app calendar">
          <h2>Here to help you keep track of all those jobs you apply for!</h2>
          <p> We will simplify the process of applying for jobs by keeping
            track of all the important information for you.</p> 
          <p>We'll allow you to enter details on companies, contacts and jobs
            and connect these together.</p>
          <p>We present all this information in an easy to read format with the
            focus being a calender showing timings for all your job applications.</p>
        </div>
      </div>
      <div class="container-fluid">
        <h1>What we do</h1>
          <p>We will help simplify the process of applying for jobs by keeping
            track of all the important information for you.You can enter details
            on companies, contacts and jobs and connect these together. Jobs
            will be displayed in a easy to read calendar format based on the
            key dates. </p>
      </div>
      <div class="container-fluid">
        <h2>Features</h2>
        <div class="row">
            <div class="col-sm-4">
              <h3>Contacts</h3>
              <p>You can enter and keep track of all your job related contacts,
                 linking them with the application they are responsible for.</p>
            </div>
            <div class="col-sm-4">
              <h3>Companies</h3>
              <p>You can enter details on companies you are interested in,
                and link with the relevant contacts and jobs.</p>
            </div>
            <div class="col-sm-4">
              <h3>Jobs</h3>
              <p>You can enter Jobs you want to ,are currently applying or
                have previously applied for, helping you to keep this all straight.</p>
            </div>
          </div>
      </div>
    </div>
  </body>
</html>
