	<?php

			require_once 'phpfunctions/header.php';

			// Create connection
			$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
			// Check connection
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}
			$currentUsername = $current->username();
			$sql = "SELECT * FROM contacts WHERE username= '$currentUsername'";
			$result = mysqli_query($conn, $sql); ?>
<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>


<div class="container">
  <h2>Contact List</h2>

      <a href="contact.php" class="btn btn-info" role="button" id='add'>Add new Contact</a>

  <p></p>
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Company</th>
        <th>Type</th>
		<th>Phone</th>
		<th>Email</th>
		<th>Location</th>
      </tr>
    </thead>




	<tbody>
<?php
		while( $company = mysqli_fetch_array($result)){

		echo "<tr id = '".$company['name']."-".$company['company']."'href='contactDetails.php'><td>".$company['name']."</td><td>".$company['company']."</td><td>".$company['type']."</td><td>".$company['phone']."</td><td>".$company['email']."</td><td>".$company['location']."</td></tr>";

	}
	?>
	<?php
	mysqli_close($conn); ?>
	</tbody>
  </table>

</div>

<script>
jQuery(document).ready(function($) {
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});

$('tr[href]').on("click", function() {
	window.localStorage.setItem("company", $(this).attr('id'));
	window.localStorage.setItem("name", $(this).attr('id'));
	var contactKey = $(this).attr('id');
	var contactName = contactKey.split("-")[0];
	var companyName = contactKey.split("-")[1];
	window.location.href = 'contactDetails.php?companyName=' + companyName + '&contactName=' + contactName;
});
</script>

</body>
</html>
