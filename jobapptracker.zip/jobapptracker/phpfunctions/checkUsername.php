<?php

//<!-this file is called by the AJAX script in register.html page.
//It reads the database to see if the requested username already exists->

//get database access parameters
require_once 'config.php';

//get the parameter passed from the AJAX javascript
$username = $_REQUEST["q"];

// Create database connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
//echo "TESTING..connection status is " .$conn->connect_errno ."<br/>";

// Check database connection
if ($conn->connect_error) {
	$output = "database connection failed";
}

//see if $username exists in the database
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);

$result = $stmt->execute();
$stmt->store_result();

//check if database operation was successful
if (!$result) {
	$output = "database query was malformed";
} elseif ($stmt->num_rows > 0) {
	//see if the database query returned an existing user
	$output = "exists";
} else {
	$output = "nice work, your username is unique";
}

//close database connection
$conn->close();
$stmt->close();

//send the result
echo $output;

?>
