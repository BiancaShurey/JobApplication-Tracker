<?php

//<!-this file is called by the userDetails page
//when the user submits a form to change their password or email or username or 
//phone number.->

//first check if user is logged in
session_start();
require 'config.php';
require_once 'classes.php';
$currentUser = new currentUser();
if ($currentUser->username())
{
	$username = $currentUser->username();
}
else {
	$_SESSION['message'] = "Please log in to use your Details page";
	header("Location: login.php");
	exit;
}

//get any new user parameters that have been specified
$newemail = @$_REQUEST["newemail"];
$newphone = @$_REQUEST["newphone"];
$newusername = @$_REQUEST["newusername"];
$newpassword = @$_REQUEST["newpassword"];

//get existing parameters from Session or Cookies
$username = $currentUser->username();
$passwordhash = $currentUser->password();
$email = $currentUser->email();
$phone = $currentUser->phone();

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	$_SESSION['message'] = "whoops, failed to connect to database...".$conn->connect_error;
	header("Location: userDetails.php");
	exit;
} 

//formulate the SQL update
if ($newemail) {
	// prepare and bind
	$stmt = $conn->prepare("UPDATE users SET email = ? WHERE username = ?");
	$stmt->bind_param("ss", $newemail, $username);
	$email = $newemail;	//for updating the session/cookies below
} elseif ($newphone) {
	$stmt = $conn->prepare("UPDATE users SET phone = ? WHERE username = ?");
	$stmt->bind_param("ss", $newphone, $username);
	$phone = $newphone;	//for updating the session/cookies below
} elseif ($newusername) {
	$stmt = $conn->prepare("UPDATE users SET username = ? WHERE username = ?");
	$stmt->bind_param("ss", $newusername, $username);
	$username = $newusername;	//for updating the session/cookies below
} else {
	$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
	$newpasswordhash = password_hash($newpassword, PASSWORD_DEFAULT);
	$stmt->bind_param("ss", $newpasswordhash, $username);
	$passwordhash = $newpasswordhash;	//for updating the session/cookies below
}

//send SQL 
$result = $stmt->execute();
$conn->close();

if ($result)
{
	//update was successfull, so create a message for the user
	$_SESSION['message'] = "Your details have been updated";
	//update the session details
	$currentUser->setAll($username, $passwordhash, $email, $phone);
}
else {
	$_SESSION['message'] = "Hmmm, we weren't ablt to update yo details sorry. Perhaps try again...";
}
header("Location: ../userDetails.php");
exit;


?>
