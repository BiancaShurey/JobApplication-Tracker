<?php
session_start();
//bring in config file to gain access to support functions
require 'config.php';
require_once 'classes.php';
include 'sessionMessage.php';
$current = new currentUser();
// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT ID AS id, Title AS title, start, `end` FROM applications WHERE username='".$current->username()."'";
$result = $conn->query($sql);

$emparray = array();
while($row =mysqli_fetch_assoc($result))
{
    $emparray[] = $row;
}
$myJSON = json_encode($emparray);
echo  $myJSON;

$conn->close();
?>
