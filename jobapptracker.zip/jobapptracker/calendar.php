<?php require 'phpfunctions/header.php';?>
		 <script>
			$(document).ready(function() {
		                $('#calendar').fullCalendar({
                      header: {
                  				left: 'prev,next today',
                  				center: 'title',
                  				right: 'month,basicWeek,basicDay'
                  			},
		                  events: 'phpfunctions/getdates.php',
											height: 600,
                      navLinks: true, // can click day/week names to navigate views
                			editable: true,
                			eventLimit: true, // allow "more" link when too many events
                      eventClick: function(event) {
                            window.location.href='applicationDetails.php?id='+event.id;
                            return false;}
		              });
									$('#list').fullCalendar({
										header: {
													left: 'prev,next today',
													center: 'title',
													right: 'listDay,listWeek'
												},
												// customize the button names,
												// otherwise they'd all just say "list"
												views: {
													listDay: { buttonText: 'list day' },
													listWeek: { buttonText: 'list week' }
												},
                    navLinks: true, // can click day/week names to navigate views
              			editable: true,
              			eventLimit: true, // allow "more" link when too many events
										defaultView: 'listWeek',
										events: 'phpfunctions/getdates.php',
										height: 550,
                    eventClick: function(event) {
                        window.location.href='applicationDetails.php?id='+event.id;
                        return false;
    }});
							});
		</script>
	<div id='calendar'></div>
  <div id='left'>
      <a href="newApplication.php" class="btn btn-info" role="button" id='add'>Add new Application</a>
  	<div id='list'></div>

</body>
</html>
