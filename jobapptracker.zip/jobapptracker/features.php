<?php require 'phpfunctions/header.php';?>
    <div class="main">
      </div>
      <div class="container-fluid current">
        <div class=title><h2>Features</h2></div>
<div class="row">
            <div class="col-sm-4">
              <h3>Contacts</h3>
              <p>You can enter and keep track of all your job related contacts,
                 linking them with the application they are responsible for.</p>
                 <p>You can store details such as their contact details, the company they represent and location.</p>
            </div>
            <div class="col-sm-4">
              <h3>Companies</h3>
              <p>You can enter details on companies you are interested in,
                and link with the relevant contacts and jobs.</p>
                <p> Information about the company can be stored including info on their culture and finances.</p>
            </div>
            <div class="col-sm-4">
              <h3>Jobs</h3>
              <p>You can enter Jobs you want to ,are currently applying or
                have previously applied for, helping you to keep this all straight.</p>
                <p> You can enter and store details about the position and and key dates related to the initial application.</p>
            </div>
          </div>
	  <div class='row'>
	    <div class="col-sm-12"><h2> Upcoming features</h2></div>
	  </div>
	  <div class="row">
            <div class="col-sm-4">
              <h3>Notifications</h3>
              <p>You will be able to see if a job's closing date is imminent and recieve emails informing you if it is. </p>
	      <p>You can recieve a notifcation via email of jobs you expect to hear back from soon. You can opt to recieve other useful information via email as well.</p></div>
            <div class="col-sm-4">
              <h3>Data analysis</h3>
              <p>You will be able to see graph showing ypou your progress on your job search, illusratating components like amount applied for
		over time and the location distribution of jobs</p>
                <p>You will be able to search through jobs, companies and contacts for ones that fulfill your criteria.</p>
            </div>
            <div class="col-sm-4">
              <h3>Categorisation</h3>
              <p>You will be able to categorise jobs, companies and contacts by a variety of different tags and use these to help you plan your job search.</p>
                <p> The colours of jobs on the calendar will be customisable and you will be able to add details of additional stages
		of the application process such as assessment centres and interviews.</p>
            </div>
          </div>
      </div>
    </div>
  </body>
</html>
