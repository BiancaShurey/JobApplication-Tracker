<?php

//get information passed in from form submission
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];
$company = $_REQUEST["company"];

//bring in the config file
require 'config.php';

//Bring in the classes file in order to write to server log
require 'classes.php';
$logger = new ServerLog("getCompany");
$logger->recordPostParams($_REQUEST);

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "hmm, the database connection didn't work :(, the error was ".$conn->connect_error;
	$conn->close();
	exit;
} 

//Check user credentials
$sql = "SELECT username, password FROM users WHERE username = '$username'";
$result = $conn->query($sql);
if (!$result) {
	echo "your username appears to be incorrect";
	$conn->close();
	exit;
} else {
	while ($row = $result->fetch_assoc()) {
		if (!password_verify($password, $row['password'])) {
			echo "your password is incorrect";
			$conn->close();
			exit;
		}
	}
}

$stmt = $conn->prepare("SELECT * FROM `companies` WHERE username = ? AND Company = ?");
$stmt->bind_param("ss", $username, $company);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_object()) {
		echo json_encode($row);
}

$conn->close();
$stmt->close();

?>
