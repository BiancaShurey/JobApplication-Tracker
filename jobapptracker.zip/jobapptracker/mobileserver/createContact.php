<?php

//this file accepts a JSON object and enters the info contained in the 
//object into the database.

//$postInput = json_decode(file_get_contents('php://input'), true);
$username = $_REQUEST["username"];
$company = $_REQUEST["company"];
$name = $_REQUEST["name"];
$type = $_REQUEST["type"];
$email = $_REQUEST["email"];
$phone = $_REQUEST["phone"];
$location = $_REQUEST["location"];

//bring in the config file
require 'config.php';

//Bring in the classes file in order to write to server log
require 'classes.php';
$logger = new ServerLog("createContact");
$logger->recordPostParams($_REQUEST);

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "hmm, the database connection didn't work :(, the error was ".$conn->connect_error;
	$conn->close();
	exit;
} 

//make sure $company exists in Companies table (it is a foreign key)
$sql = "SELECT * FROM `companies` WHERE username = '$username' AND Company = '$company'";
$result = $conn->query($sql);
//check if database operation was successful
if (!$result) {
	//database query was malformed
	echo "o-oh, something went wrong with checking the Companies table";
	$conn->close();
	exit;
}
if ($result->num_rows == 0) {
	//then we need to add the $company to the Companies table
	//formulate sql insert statement
	$sql = "INSERT INTO companies (Company,	username) VALUES ('$company', '$username')";
	//check query success
	if (!$conn->query($sql)) {
		//the operation failed
		echo "whoops, we couldn't add the company to the companies table";
		$conn->close();
		exit;
	}
}

//create SQL insert command for applications table
$sql = "INSERT INTO contacts (company, name, type, email, phone, 
location, username) VALUES ('$company', '$name', '$type', '$email', '$phone', 
'$location', '$username')";

$logger->record($sql);

//check query success
if ($conn->query($sql)) {
	//the application was added successfully
	echo "ok";
} else {
	//the update failed
	echo "whoops, something went wrong, please try to add the application again";
}

$conn->close();

?>
