<?php

//<!-this file is called by the login.php page after the user submits
//the form for forgotten login details. If the user provides the correct email
//and phone in the form, then this script sends them an email with their 
//username and new password->

session_start();
$email = $_REQUEST["email"];
$phone = $_REQUEST["phone"];

//bring in the config file to get the database access credentials
require 'config.php';

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "database connection failure";
	die("Connection failed: " . $conn->connect_error);
} 

//query the database
$sql = "SELECT * FROM users WHERE email = '$email' AND phone = '$phone'"; 
$result = $conn->query($sql);

//parse the query results
if ($result->num_rows > 0)
{
	while ($row = $result->fetch_assoc())
	{
		$username = $row['username'];
	}
} else {
	//the supplied credentials aren't found
	echo "Seems that email/phone are incorrect, have another go...";
	$conn->close();
	exit;
}

//reset the user's password
$newpassword = 'wigwam'.rand();
$newpasswordhash =  password_hash($newpassword, PASSWORD_DEFAULT);
$sql = "UPDATE users SET password = '$newpasswordhash' WHERE username = '$username'";
$result = $conn->query($sql);

$conn->close();

//send email to the user
$emailMessage = "Hi there!\r\n
Your username is $username and your temporary password is $newpassword.\r\n
You can change this password by logging in and navigating to 'My Details'\r\n";

//To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$subject = "Your JobAppTracker login details";

$mailStatus = mail($email, $subject, $emailMessage, $headers);

//send the user back to the login page
echo "ok";
exit;

?>
