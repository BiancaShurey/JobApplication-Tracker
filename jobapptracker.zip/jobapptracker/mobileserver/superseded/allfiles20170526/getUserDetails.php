
<?php

//<!-this file is called by the applicationDetails.php page after the user submits the 
//form on that page

//get information passed in from form submission
$usernameGiven = $_REQUEST["username"];
$passwordGiven = $_REQUEST["password"];

//bring in the config file
require 'config.php';

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "hmm, the database connection didn't work :(, the error was ".$conn->connect_error;
	$conn->close();
	exit;
} 

$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $usernameGiven);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_object()) {
	
	//CHeck password was correct
	if (!password_verify($passwordGiven, $row->password)) {
			echo "your password is incorrect";
			$conn->close();
			exit;
	}
	//echo $row->password."--".$usernameGiven."--".$passwordGiven."--".json_encode($row);
	echo json_encode($row);
}

$stmt->close();
$conn->close();

?>
