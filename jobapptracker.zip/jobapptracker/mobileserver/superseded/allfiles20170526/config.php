
<?php 
//this file stores the database access credentials, which are 
//retrieved by other php files using the command "require 'config.php' "
$servername = "localhost";
$dbusername = "root";
$dbpassword = "steveyoung";
$dbname = "jobapptracker";

$fcmKey = "AAAAuYMiZUc:APA91bFpg2FR7cVv6VxfK3t4LxlAApvLROakgIKtVP4m3n0XPA240iUwEGfwZctVH8lFJyYvRHJMTpxQ7NCEbie11Rh7JLykh5eZqdZqNx1mYTVaF9F7fJylkwV6C5j8YYxzUXKfj-wO";
?>
