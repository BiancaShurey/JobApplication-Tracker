<?php

//require_once 'classes.php';
require_once 'config.php';
$username = $_REQUEST["q"];

//Get details of this application from database		
// Create database connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check database connection
if ($conn->connect_error) {
	echo "Couldn't access database";
	$conn->close();
	exit;
}

//create SQL query for company
$sql = "SELECT * FROM applications WHERE username = '$username'";
$result = $conn->query($sql);

//check if database queries were successful
if (!$result) {
	echo "Couldn't find the username in the database";
	$conn->close();
	exit;
}

$resultsList = array();
//Get parameters from query result
while ($row = $result->fetch_assoc())
{
	//$app = new Application($row);
	$app = new stdClass;
	$app->company = $row['Company'];
	$app->title = $row['Title'];
	$app->type = $row['type'];
	$app->duration = $row['duration'];
	$app->site = $row['site'];
	$app->released = $row['released'];
	$app->closes = $row['closes'];
	$app->applied = $row['applied'];
	$app->selectionCriteria = $row['selectionCriteria'];
	$app->hearFrom = $row['hearFrom'];
	$app->location = $row['location'];
	$app->commences = $row['commences'];
	$app->username = $row['username'];
	array_push($resultsList, $app);
}

echo json_encode($resultsList);
$conn->close();

?>