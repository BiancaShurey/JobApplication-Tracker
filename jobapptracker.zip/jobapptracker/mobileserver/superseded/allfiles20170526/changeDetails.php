<?php

//<!-this file is called by the userDetails page
//when the user submits a form to change their password or email or username or 
//phone number.->
header('Access-Control-Allow-Origin: *');
require 'config.php';

//get any new user parameters that have been specified
$newemail = @$_REQUEST["newemail"];
$newphone = @$_REQUEST["newphone"];
$newusername = @$_REQUEST["newusername"];
$newpassword = @$_REQUEST["newpassword"];
$newpasswordhash = password_hash($newpassword, PASSWORD_DEFAULT);

//get existing parameters
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "whoops, failed to connect to database...".$conn->connect_error;
	$conn->close();
	exit;
} 

//Check the existing username and password
$stmt = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->bind_result($usernameCol, $passwordCol);
$stmt->store_result();
if ($stmt->num_rows == 0) {
	$stmt-close();
	$conn->close();
	echo "Hey that username seems incorrect";
	exit;
}

while ($stmt->fetch()) {
	if (!password_verify($password, $passwordCol)) {
		echo "password incorrect";
		$stmt-close();
		$conn->close();
		exit;
	}
}

$stmt2 = $conn->prepare("UPDATE users SET email = ?, password = ?, phone = ?, username = ? WHERE username = ?");
$stmt2->bind_param("sssss", $newemail, $newpasswordhash, $newphone, $newusername, $username);

//send SQL 
$result = $stmt2->execute();

if ($result)
{
	//update was successfull, so create a message for the user
	echo "success";
}
else {
	echo "Hmmm, we weren't ablt to update yo details sorry. Perhaps try again...";
}

$stmt->close();
$conn->close();

?>
