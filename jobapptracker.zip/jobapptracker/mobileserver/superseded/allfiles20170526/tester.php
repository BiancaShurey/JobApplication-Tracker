<?php 

echo "so is this working?"; 

$username = $_REQUEST["q"];
echo $username;

//bring in the config file to get the database access credentials
require 'config.php';

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "database connection failure";
	die("Connection failed: " . $conn->connect_error);
} 

//query the database
$sql = "SELECT * FROM users WHERE username='beau'"; 
$result = $conn->query($sql);

//parse the query results
if ($result->num_rows > 0)
{
	while ($row = $result->fetch_assoc())
	{
		$username = $row['email'];
		echo $username;
	}
} else {
	//the supplied credentials aren't found
	echo "Seems that email/phone are incorrect, have another go...";
	exit;
}

$conn->close();

?>
