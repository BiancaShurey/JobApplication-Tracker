<?php

//<!-this file is called by the companyDetails.php page after the user submits the 
//form on that page

//get information passed in from form submission
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];
$company = $_REQUEST['company'];
$type = $_REQUEST['type'];
$industry = $_REQUEST['industry'];
$values = $_REQUEST['values'];
$diversity = $_REQUEST['diversity'];
$size = $_REQUEST['size'];
$finances = $_REQUEST['finances'];
$people = $_REQUEST['people'];
$website = $_REQUEST['website'];
$focus = $_REQUEST['focus'];
$companyInitial = $_REQUEST["companyInitial"];

//bring in the config file
require 'config.php';


// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "hmm, the database connection didn't work :(, the error was ".$conn->connect_error;
	$conn->close();
	exit;
} 

//Check user credentials
$sql = "SELECT username, password FROM users WHERE username = '$username'";
$result = $conn->query($sql);
if (!$result) {
	echo "your username appears to be incorrect";
	$conn->close();
	exit;
} else {
	while ($row = $result->fetch_assoc()) {
		if (!password_verify($password, $row['password'])) {
			echo "your password is incorrect";
			$conn->close();
			exit;
		}
	}
}

//create SQL insert command for companies table
$sql = "UPDATE companies SET Company='$company', Type='$type', Industry='$industry', `Values`='$values', 
Diversity='$diversity', Size='$size', Finances='$finances', People='$people', Website='$website', 
Focus='$focus' WHERE username='$username' AND Company='$companyInitial'";

//check query success
if ($conn->query($sql)) {
	//the application was added successfully
	echo "success";
} else {
	//the update failed
	echo "whoops, something went wrong, please try to edit the company again";
}

$conn->close();

?>



