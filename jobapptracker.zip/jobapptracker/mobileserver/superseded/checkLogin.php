

<?php
//<!-this page is called from login.php after the user submits their username
//and password->

//<!-first, get the variables that were submitted from the login.php form->

$username = $_REQUEST["username"];
$password = $_REQUEST["password1"];

session_start();
//<!-now call the database to check if the username and password match->
//bring in the config file to get the database access credentials
require 'config.php';
//require_once 'classes.php';

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	//die("Connection failed: " . $conn->connect_error);
	echo "connection error";
	exit;
}

//query the database
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);

//parse the query results
if ($result->num_rows > 0)
{
	while ($row = $result->fetch_assoc())
	{
		if ($row['username'] == $username && password_verify($password, $row['password']))
		{
			//then the user credentials are correct
			echo "ok";
			exit;
		} else {
			//then the user credentials were incorrect
			echo "incorrect login credentials";
			exit;
		}
	}
} else {
	echo "incorrect login credentials";
	exit;
}

?>
