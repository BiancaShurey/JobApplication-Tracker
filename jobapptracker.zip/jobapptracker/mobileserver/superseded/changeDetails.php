<?php

//<!-this file is called by the userDetails page
//when the user submits a form to change their password or email or username or 
//phone number.->

require 'config.php';

//get any new user parameters that have been specified
$newemail = @$_REQUEST["newemail"];
$newphone = @$_REQUEST["newphone"];
$newusername = @$_REQUEST["newusername"];
$newpassword = @$_REQUEST["newpassword"];

//get existing parameters
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "whoops, failed to connect to database...".$conn->connect_error;
	$conn->close();
	exit;
} 

//Check the existing username and password
$stmt = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->bind_result($usernameCol, $passwordCol);
$stmt->store_result();
echo $stmt->num_rows;
exit;
while ($stmt->fetch()) {
	echo "into loop with ".$usernameCol.$passwordCol;
	exit;
	if (!password_verify($password, $passwordCol)) {
		echo "password incorrect";
		$conn->close();
		exit;
	}
}

//formulate the SQL update
if ($newemail) {
	// prepare and bind
	$stmt2 = $conn->prepare("UPDATE users SET email = ? WHERE username = ?");
	$stmt2->bind_param("ss", $newemail, $username);
} elseif ($newphone) {
	$stmt2 = $conn->prepare("UPDATE users SET phone = ? WHERE username = ?");
	$stmt2->bind_param("ss", $newphone, $username);
} elseif ($newusername) {
	$stmt2 = $conn->prepare("UPDATE users SET username = ? WHERE username = ?");
	$stmt2->bind_param("ss", $newusername, $username);
} else {
	$stmt2 = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
	$newpasswordhash = password_hash($newpassword, PASSWORD_DEFAULT);
	$stmt2->bind_param("ss", $newpasswordhash, $username);
}

//send SQL 
$result = $stmt2->execute();
$conn->close();

if ($result)
{
	//update was successfull, so create a message for the user
	echo "success";
}
else {
	echo "Hmmm, we weren't ablt to update yo details sorry. Perhaps try again...";
}

?>
