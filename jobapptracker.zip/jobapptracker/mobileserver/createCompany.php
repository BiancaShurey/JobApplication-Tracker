<?php

//this file accepts a JSON object and enters the info contained in the 
//object into the database.

//get information passed in from form submission
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];
$company = $_REQUEST["company"];
$type = $_REQUEST["type"];
$industry = $_REQUEST["industry"];
$values = $_REQUEST["values"];
$diversity = $_REQUEST["diversity"];
$size = $_REQUEST["size"];
$finances = $_REQUEST["finances"];
$people = $_REQUEST["people"];
$website = $_REQUEST["website"];
$focus = $_REQUEST["focus"];

//bring in the config file
require 'config.php';

//Bring in the classes file in order to write to server log
require 'classes.php';
$logger = new ServerLog("createCompany");
$logger->recordPostParams($_REQUEST);

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	echo "hmm, the database connection didn't work :(, the error was ".$conn->connect_error;
	$conn->close();
	exit;
} 

//make sure $company doesn't already exist in Companies table
$sql = "SELECT * FROM `companies` WHERE username = '$username' AND Company = '$company'";
$logger->record($sql);
$result = $conn->query($sql);
//check if database operation was successful
if (!$result) {
	//database query was malformed
	echo "o-oh, something went wrong with checking the Companies table";
	$conn->close();
	exit;
}
if ($result->num_rows > 0) {
	//then the company already exists for this user
	echo "naaa, you already have this company in your list";
	$conn->close();
	exit;
}

//create SQL insert command for companies table
$sql = "INSERT INTO companies (Company, Type, Industry, `Values`, Diversity, Size,
Finances, People, Website, Focus, username) VALUES ('$company', '$type', '$industry', '$values', 
'$diversity', $size, '$finances', '$people', '$website', '$focus', '$username')";

$logger->record($sql);

//check query success
if ($conn->query($sql)) {
	//the application was added successfully
	echo "ok";
} else {
	//the update failed
	echo "whoops, something went wrong, please try to add the application again";
}

$conn->close();

?>
