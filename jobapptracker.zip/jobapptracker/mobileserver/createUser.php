<?php

//<!-this file is called by the register.html page after the user submits
//that form. It writes the form to the database and then redirects the
//user to their userCalendar page->
header('Access-Control-Allow-Origin: *');

$username = $_REQUEST["username"];
$email = $_REQUEST["email"];
$password = $_REQUEST["password1"];
$passwordhash = password_hash($password, PASSWORD_DEFAULT);
$phone = $_REQUEST["phone"];

//bring in the config file to get the database access credentials
require 'config.php';

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO users (username, password, email, phone) VALUES
('$username', '$passwordhash', '$email', '$phone')";

if ($conn->query($sql) === TRUE) {
	//the user was created successfully
	echo "success";
	$conn->close();
	exit;
} else {
	//the registration failed
	echo "oh no, your registration didn't work";
	$conn->close();
	exit;
}

$conn->close();

?>

