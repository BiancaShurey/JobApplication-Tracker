
<?php

require_once 'phpfunctions/classes.php';
require_once 'phpfunctions/header.php';
require_once 'phpfunctions/config.php';
$current = new currentUser();	//the user that is currently logged in (if any)
if (!$current->username())
{
	//no user is logged in, so redirect to login page
	$_SESSION['message'] = "Please sign in to use your account";
	header("Location: login.php");
	exit;
}


$username = $current->username();

//Get details of this application from database
// Create database connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check database connection
if ($conn->connect_error) {
	$_SESSION['message'] = "Couldn't access database.";
	$conn->close();
	header("Location: Calendar.php");
	exit;
}

//create SQL query for application
$id=$_GET['id'];
$sql = "SELECT * FROM applications WHERE id = '$id'";
$result = $conn->query($sql);

//check if database queries were successful
if (!$result) {
	$_SESSION['message'] = "Couldn't find the application.";
	$conn->close();
	header("Location: Calendar.php");
	exit;
}

$classy = 'hear from';
while ($row = $result->fetch_assoc())
{
	$event = new Event($row, $classy);
}

//close database connection
$conn->close();

?>



<div class="main">
	<div class="container">
		<div class="title">
          <h1><?php echo $event->company().", ".$event->title(); ?></h1>
          <h2>Review/edit details for this application:</h2>
        </div>

		<form class="form-horizontal" method="POST" action="phpfunctions/updateApplication.php">
			<?php
			if(isset($_SESSION['message'])){
				echo "<p>".$_SESSION['message']."</p>";
				unset($_SESSION['message']);
			}
			?>
			<input hidden name="id" value="<?php echo $id;?>"></input>
			<div class="form-group">
				<label class="control-label col-sm-2" for="company">company:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->company();?>" type="text" id="company" name="company" class="content" onkeyup="searchCompanies(this.value)" onblur="closeSuggestions()"/><br>
				</div>
			</div>
			<div>
				<ul class="list-group" id="livesearch">
					<!--Displays suggestions according to the user typing -->
				</ul>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="title">title:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->title();?>" type="text" id="title" name="title" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="type">type:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->type();?>" type="text" id="type" name="type" class="content"/><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="duration">duration:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->duration();?>" type="text" name="duration" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="site">site:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->site();?>" type="text" name="site" class="content" /><br>
				</div>
			</div>

			<div class="form-group">
				<label class="control-label col-sm-2" for="released">released:</label>
				<div class="col-sm-10">
					<input value="<?php echo substr($event->released(), 0, 10);?>" type="date" name="released" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="closes">closes:</label>
				<div class="col-sm-10">
					<input value="<?php echo substr($event->closes(), 0, 10);?>" type="date" name="closes" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="selection">selection:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->selectionCriteria();?>" type="text" name="selection" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="hearfrom">hearfrom:</label>
				<div class="col-sm-10">
					<input value="<?php echo substr($event->hearFrom(), 0, 10);?>" type="date" name="hearfrom" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="location">location:</label>
				<div class="col-sm-10">
					<input value="<?php echo $event->location();?>" type="text" name="location" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-2" for="commences">commences:</label>
				<div class="col-sm-10">
					<input value="<?php echo substr($event->commences(), 0, 10);?>" type="date" name="commences" class="content" /><br>
				</div>
			</div>
			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
					<div class="checkbox">
						<?php
						if ($event->applied() == 'y') {
							echo "<label><input checked=\"true\" type=\"checkbox\" name=\"applied\"> Applied already?</label>";
						} else {
							echo "<label><input type=\"checkbox\" name=\"applied\"> Applied already?</label>";
						};
						?>
					</div>
				</div>
			</div>

			<!-- Application details before changes -->
			<input value="<?php echo $event->company();?>" type="text" id="companyInitial" name="companyInitial" class="content" /><br>
			<input value="<?php echo $event->title();?>" type="text" id="titleInitial" name="titleInitial" class="content" /><br>

			<div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
					<button type="submit" class="btn btn-default">Submit changes</button>
				</div>
			</div>
		</form>
	</div>
</div>

<script>
function closeSuggestions() {
	//closes the livesearch results box when the user clicks out of the Company field
	//hide the livesearch element (after a delay, to give time for the user to select an item
	//from the livesearch box)
	setTimeout(function(){$("#livesearch").slideUp();}, 500);
};
</script>

<script>
//Things to do when page is ready
$(document).ready(function(){
    //bind the livesearch results element so that it disappears after it is clicked
    $("#livesearch").click(function(){
        $("#livesearch").hide();
    });
    //hide the modals
    $(".w3-modal").hide();
	//hide the original app elements
	document.getElementById("companyInitial").style.display = "none";
	document.getElementById("titleInitial").style.display = "none";
});
</script>

<script>

//this function enables a live search for the Company text field
function searchCompanies(str) {
	
	if (str.length==0) {
		$("#livesearch").empty();
		$("#livesearch").hide();
		//document.getElementById("livesearch").innerHTML="";
		//document.getElementById("livesearch").style.border="0px";
		return;
	}
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function() {
		if (this.readyState==4 && this.status==200) {
		
			//Convert response text to list and pass to
			//"displaySearch" method
			var list = JSON.parse(this.responseText);
			displaySearch(list);
		
		}
	};
	xmlhttp.open("GET","https://infs3202-dwrqj.uqcloud.net/jobapptracker/mobileserver/searchCompanies.php?q="+str,true);
	xmlhttp.send();
}

//Display the livesearch box with a list
function displaySearch(list) {

	$("#livesearch").empty();
	$("#livesearch").show();
	
	for (i=0; i<list.length; i++) {
	
		var result = list[i];
		var listItem = "<li class='list-group-item' onclick='selectResult(this)'>" + 
			result + "</li>";
		$("#livesearch").append(listItem);
	
	}
	
	//document.getElementById("livesearch").style.border="1px solid #A5ACB2";			

}

//Sets the Company field to the text contained in the clickedElement
function selectResult(clickedElement) {

	//alert('text is ' + clickedElement.innerText);
	$("#company").val(clickedElement.innerText);

}

</script>

</body>
</html>
