<?php require 'phpfunctions/header.php';?>
<div class="container">

<div class="page-header">
    <h1>Frequently Asked Questions</h1>
</div>
<div class="container">
    <div class="panel-group" id="accordion">
        <div class="faqHeader">Job Applicants</div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Can I apply for jobs through <strong>Japlendar?</strong></a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse">
                <div class="panel-body">
                    <p>Currently <strong>Japlendar</strong> only allows you to track applications. Applying for jobs thorugh <strong>Japlendar</strong> isn't a feature being considered at this time.</p>
                </div>
            </div>
        </div>
		<div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Is account registration free?</a>
                </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse">
                <div class="panel-body">
                    The account at <strong>Japlendar</strong> is completely free.
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Where do I submit my resume?</a>
                </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse">
                <div class="panel-body">
                    As you currently cannot apply for jobs through our service, resume submission or uploads are unavaible at this time.
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">How can I know about my application status?</a>
                </h4>
            </div>
            <div id="collapseFour" class="panel-collapse collapse">
                <div class="panel-body">
                    You currently will need to check <strong>Japlendar</strong> to see what applications have deadlines soon. Soon you will be able to receive email notifications regarding the updates such as applications closing, desired follow up, and the status of the application.
                </div>
            </div>
        </div>

		<div class="faqHeader">Employers</div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">Can we offer jobs to applicants and communicate with them through <strong>Japlendar</strong>?<a>
                </h4>
            </div>
            <div id="collapseSeven" class="panel-collapse collapse">
                <div class="panel-body">
                    Currently this ablity is unavaible as <strong>Japlendar</strong>'s focus is on helping job seekers keep track of all their current applications. It may be considered at a later time.                </div>
            </div>
        </div>
    </div>
</div>

</div>

</body>
</html>
